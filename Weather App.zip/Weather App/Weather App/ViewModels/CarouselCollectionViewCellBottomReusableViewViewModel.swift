//
//  CarouselCollectionViewCellBottomReusableViewViewModel.swift
//  Weather App
//
//  Created by bacho kartsivadze on 24.01.23.
//

import Foundation

struct CarouselCollectionViewCellBottomReusableViewViewModel {
    let systemImageName: String
    let infoText: String
    let valueText: String
}
